const React = require('react');
import NavigationBar from "../Navbar"

export default class MulticastMAC extends React.Component {

    render(){

        return(

            <div>
            <NavigationBar/>
            <h2>Multicast Mac Address</h2>
            </div>
        )
    }
}