/**
 * Created by kgb on 9/14/17.
 */
const React = require('react');
import NavigationBar from "../Navbar"

export default class ATOI extends React.Component {

    render(){

        return(

            <div>
            <NavigationBar/>
            <h2>ATOI</h2>
            </div>
        )
    }
}