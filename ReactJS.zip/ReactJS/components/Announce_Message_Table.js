/**
 * Created by kgb on 9/12/17.
 */

const React = require("react");
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table'



export default class Announce_Message_Table extends React.Component {


    render() {

        var announce_messages = this.props.data;
        let clockidentity = [];
        let GMClockID = [];
        let GMClockClass = [];
        let GMClockVariance = [];
        let GMClockAccuracy = [];
        let Ethernet = [];
        let IP = [];
        let priority_1 = [];
        let priority_2= [];
        let timesource = [];
        let sequence_id = [];
        let timestamp = [];

        var tableData = Object.keys(announce_messages).map(function(key){

            clockidentity.push([announce_messages[key].clockidentity]);
            GMClockID.push([announce_messages[key].GMClockIdentity]);
            GMClockClass.push([announce_messages[key].GMClockClass]);
            GMClockVariance.push([announce_messages[key].GMClockVariance]);
            GMClockAccuracy.push([announce_messages[key].GMClockAccuracy]);
            Ethernet.push([announce_messages[key].ETH_DST]);
            IP.push([announce_messages[key].IP_DST]);
            priority_1.push([announce_messages[key].priority_1]);
            priority_2.push([announce_messages[key].priority_2]);
            timesource.push([announce_messages[key].timesource]);
            sequence_id.push([announce_messages[key].sequence_id]);
            timestamp.push([announce_messages[key].sniff_timestamp]);

            return({

                    "clockidentity": clockidentity.pop(),
                    "GMClockIdentity": GMClockID.pop(),
                    "GMClockClass": GMClockClass.pop(),
                    "GMClockVariance": GMClockVariance.pop(),
                    "GMClockAccuracy": GMClockAccuracy.pop(),
                    "ETH_DST": Ethernet.pop(),
                    "IP_DST": IP.pop(),
                    "priority_1": priority_1.pop(),
                    "priority_2": priority_2.pop(),
                    "timesource": timesource.pop(),
                    "sequence_id": sequence_id.pop(),
                    "timestamp": timestamp.pop(),
                }
            )

        });

        return(

            <div className="container-table" id="Announce_Message_Table">
                <table className="table message"><thead><tr><th>Announce Messages</th></tr></thead></table>
            <BootstrapTable data={tableData}  height={400} bodyStyle={{overflow: 'overlay'}} scrollTop={'Bottom'} options={ { noDataText: 'Connect to an Interface to Start Reading Announce Messages' } } striped hover>
              <TableHeaderColumn dataField="clockidentity" headerAlign='center'>ClockIdentity</TableHeaderColumn>
                <TableHeaderColumn dataField="GMClockIdentity" headerAlign='center'>GM ID</TableHeaderColumn>
                    <TableHeaderColumn dataField="GMClockClass" headerAlign='center'>GM Class</TableHeaderColumn>
                    <TableHeaderColumn dataField="GMClockVariance" headerAlign='center'>GM Variance</TableHeaderColumn>
                    <TableHeaderColumn dataField="GMClockAccuracy" headerAlign='center'>GM Accuracy</TableHeaderColumn>
                    <TableHeaderColumn dataField="ETH_DST" headerAlign='center'>Ethernet</TableHeaderColumn>
                    <TableHeaderColumn dataField="IP_DST" headerAlign='center'>IP</TableHeaderColumn>
                    <TableHeaderColumn dataField="priority_1" headerAlign='center'>Priority 1</TableHeaderColumn>
                    <TableHeaderColumn dataField="priority_2" headerAlign='center'>Priority 2</TableHeaderColumn>
                    <TableHeaderColumn dataField="timesource" headerAlign='center'>Timesource</TableHeaderColumn>
                    <TableHeaderColumn dataField="sequence_id" headerAlign='center'>Sequence ID</TableHeaderColumn>
                    <TableHeaderColumn dataField="timestamp" isKey={true}>Timestamp</TableHeaderColumn>
            </BootstrapTable>
            </div>

        )
    }
}

/*

return(
   <tr key={key}>

                    <td>{announce_messages[key].clockidentity}</td>
                    <td>{announce_messages[key].GMClockIdentity}</td>
                    <td>{announce_messages[key].GMClockClass}</td>
                    <td>{announce_messages[key].GMClockVariance}</td>
                    <td>{announce_messages[key].GMClockAccuracy}</td>
                    <td>{announce_messages[key].ETH_DST}</td>
                    <td>{announce_messages[key].IP_DST}</td>
                    <td>{announce_messages[key].priority_1}</td>
                    <td>{announce_messages[key].priority_2}</td>
                    <td>{announce_messages[key].timesource}</td>
                    <td>{announce_messages[key].sequence_id}</td>
                    <td>{announce_messages[key].sniff_timestamp}</td>


                </tr>
)

return (


            <div className="container-table" id="Announce_Message_Table">
                <table className="table message"><thead><tr><th>Announce Messages</th></tr></thead></table>
                 <table className="table table-bordered table-striped">

                     <thead>
                     <tr className="headers">
                         <th width="12%">Clock Identity</th>
                         <th width="12%">GMClock ID</th>
                         <th width="6%">GMClock Class</th>
                         <th width="6%">GMClock Variance</th>
                         <th width="6%">GMClock Accuracy</th>
                         <th width="12%">Destination Ethernet</th>
                         <th width="6%">Destination IP</th>
                         <th width="6%">Priority 1</th>
                         <th width="6%">Priority 2</th>
                         <th width="6%">Timesource</th>
                         <th width="6%">Sequence ID</th>
                         <th width="12%">Timestamp</th>
                     </tr>
                     </thead>
                     <tbody>
                     {output}
                     </tbody>
                </table>
            </div>
    */