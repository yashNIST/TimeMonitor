/**
 * Created by kgb on 9/14/17.
 */
const React = require('react');
import NavigationBar from "../Navbar"

export default class Holdover extends React.Component {

    render(){

        return(

            <div>
            <NavigationBar/>
            <h2>Holdover</h2>
            </div>
        )
    }
}