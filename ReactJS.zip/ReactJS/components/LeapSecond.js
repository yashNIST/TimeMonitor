/**
 * Created by kgb on 9/14/17.
 */
const React = require('react');
import NavigationBar from "../Navbar"

export default class LeapSecond extends React.Component {

    render(){

        return(

            <div>
            <NavigationBar/>
            <h2>Leap Second</h2>
            </div>
        )
    }
}