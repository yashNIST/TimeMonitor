import { render } from "react-dom"
const React = require("react");
import {HashRouter as Router, Route, Switch} from 'react-router-dom'
import 'babel-polyfill';

import {
  createStore,
  compose,
  applyMiddleware,
  combineReducers,
} from "redux"
import { Provider } from "react-redux"
import thunk from "redux-thunk"

import DashboardContainer from "./containers/DashboardContainer"
import Announce_Message_Table from "./components/Announce_Message_Table"
import BMCA from "./components/BMCA"
import Holdover from "./components/Holdover"
import LeapSecond from "./components/LeapSecond"
import ATOI from "./components/ATOI"

import * as reducers from "./reducers/reducers"
import MulticastMAC from "./components/MulticastMAC";

let finalCreateStore = compose(
  applyMiddleware(thunk),
  window.devToolsExtension ? window.devToolsExtension() : f => f
)(createStore)
let reducer = combineReducers(reducers)
let store = finalCreateStore(reducer)

class Dashboard extends React.Component{

    /*
    loadAnnounce_MessagesFromServer(){
        $.ajax({
            url: this.props.url,
            datatype: 'json',
            cache: false,
            success: function(data) {
                this.setState({data: data});
            }.bind(this)
        })
    },

    getInitialState: function() {
        return {data: []};
    },

    componentDidMount: function() {
        this.loadAnnounce_MessagesFromServer();
        setInterval(this.loadAnnounce_MessagesFromServer,
                    this.props.pollInterval)
    },
    */
    render() {

        return (

            <Provider store={store}>
                <DashboardContainer/>
            </Provider>
        )
    }

}

render(

    <Router>
        <Switch>
        <Route exact path={'/'} component={Dashboard}/>
        <Route path={'/BMCA'} component={BMCA}/>
        <Route path={'/Holdover'} component={Holdover}/>
        <Route path={'/LeapSecond'} component={LeapSecond}/>
        <Route path={'/ATOI'} component={ATOI}/>
            <Route path={'/MulticastMAC'} component={MulticastMAC}/>
        </Switch>
    </Router>
  ,
    document.getElementById('Dashboard'));


  /*Dashboard.propTypes = {

  children: React.PropTypes.object.isRequired

};*/